# 单节流程样例：已有稿件保护

本例研究本仓库的真实 `init_workspace.py`，主题为“论文工作区初始化中的已有稿件保护”。它演示原始材料、证据、蓝图、草稿、两类审查和单节定稿之间的关系，不是一篇真实毕业论文。

演示范围预先固定，程序中的已有入口文本是测试输入；没有冒充真实作者访谈、学校模板、调查或实验研究。运行观察来自实际临时目录操作，原件为 [observation.json](observation.json)，源码定位见 [初始化脚本](../../scripts/init_workspace.py)。

## 复跑

在仓库根目录执行：

```text
python -B scripts/run_worked_example.py
```

默认仅在临时目录运行并输出 JSON，不改仓库记录。更新公开观察时明确指定：

```text
python -B scripts/run_worked_example.py --output examples/initialization-study/observation.json
```

流程为预览、最小初始化、写入测试入口、扩充 software、重复运行，实际比较文件字节、时间戳和接续清单。解释器和操作系统信息如实记录，后续环境可能不同。

## 写作链

1. [证据](evidence.md)：区分代码机制和运行观察，列明可支持的主张。
2. [章节蓝图](blueprint.md)：确定一个小节的论点、证据与顺序。
3. [待审稿](draft.md)：基于上述材料形成初稿。
4. [事实与表达审查](review.md)：回查机制和结果，修改表述并保留边界。
5. [单节定稿](final.md)：可连续阅读的小节正文。

机械断言可复跑；学术表达与专业论证仍需阅读判断，不用关键词匹配冒充写作质量评分。本例没有测试 Word 版式、完整论文覆盖、真实作者多轮互动或其他学科方法，不能据此声称报告指出的完整论文验证已经完成。
